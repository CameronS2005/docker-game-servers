Please follow the TShock for Terraria [contributing guidelines](https://github.com/NyxStudios/TShock/blob/general-devel/CONTRIBUTING.md) when applicable.
