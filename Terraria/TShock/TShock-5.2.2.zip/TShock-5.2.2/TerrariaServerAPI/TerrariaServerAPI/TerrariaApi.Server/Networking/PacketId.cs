﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClientApi.Networking
{
	public enum PacketId
	{
		Version = 1
	}
}
