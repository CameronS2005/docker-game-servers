* [☕️⚡️ TShock documentation home](/)
* [Changelog](/changelog.md)
* [Command line parameters](/command-line-parameters.md)
* [Docker setup](/docker.md)

* Subsystems
  * [Tile providers](/tile-providers.md)
  * [Message-of-the-day](/motd.md)
  * [Server-side characters](/ssc.md)
  * [Languages](/lang.md)

* Field definitions
  * [Permissions](/permission-descriptions.md)
  * [REST fields](/rest-fields.md)
  * [config.json fields](/config-file-descriptions.md)
  * [sscconfig.json fields](/ssc-config.md)

* Developer documentation
  * [i18n in the tshock project](/i18n.md)
